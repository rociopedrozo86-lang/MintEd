const { Wallet } = require("ethers");

// Debe coincidir EXACTAMENTE con CLAIM_TYPEHASH de MintXP.sol:
// "Claim(address user,uint256 activityId,uint256 amount,uint256 deadline)"
const TYPES = {
  Claim: [
    { name: "user", type: "address" },
    { name: "activityId", type: "uint256" },
    { name: "amount", type: "uint256" },
    { name: "deadline", type: "uint256" },
  ],
};

/**
 * @param {{privateKey: string, chainId: number, mintXP: string, amount: bigint, deadlineSeconds: number}} cfg
 */
function makeSigner(cfg) {
  const wallet = new Wallet(cfg.privateKey);
  // Debe coincidir con EIP712("MintXP", "1") del contrato, la red y la dirección desplegada.
  const domain = {
    name: "MintXP",
    version: "1",
    chainId: cfg.chainId,
    verifyingContract: cfg.mintXP,
  };

  return {
    address: wallet.address,
    domain,
    async signClaim({ user, activityId }) {
      const amount = cfg.amount;
      const deadline = Math.floor(Date.now() / 1000) + cfg.deadlineSeconds;
      const signature = await wallet.signTypedData(domain, TYPES, { user, activityId, amount, deadline });
      // amount como string: es un uint256 y no entra seguro en un number de JS
      return { amount: amount.toString(), deadline, signature };
    },
  };
}

module.exports = { TYPES, makeSigner };
