const test = require("node:test");
const assert = require("node:assert/strict");
const { Wallet, verifyTypedData, parseEther } = require("ethers");
const { createServer } = require("../server");
const { createProgress } = require("../progress");
const { ACTIVITIES } = require("../activities");
const { TYPES } = require("../sign");

const wallet = Wallet.createRandom();
const cfg = {
  privateKey: wallet.privateKey,
  chainId: 11155111,
  mintXP: "0x1111111111111111111111111111111111111111",
  amount: parseEther("10"),
  deadlineSeconds: 600,
  allowedOrigin: "http://localhost:8000",
  progress: createProgress({ maxAttempts: 3, lockoutMs: 24 * 3600 * 1000 }),
};

let base;
let server;
let signer;

test.before(async () => {
  ({ server, signer } = createServer(cfg));
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});

test.after(() => server.close());

const newUser = () => Wallet.createRandom().address;
const questionsOf = (id, attempt = 1) => ACTIVITIES.find((a) => a.id === id).sets[attempt - 1];
const rightAnswers = (id, attempt = 1) => questionsOf(id, attempt).map((q) => q.correct);
const wrongAnswers = (id, attempt = 1) => questionsOf(id, attempt).map((q) => (q.correct + 1) % q.options.length);

const post = (path, body, raw = false) =>
  fetch(`${base}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: raw ? body : JSON.stringify(body),
  });
const submit = (user, activityId, answers) => post("/submit-answers", { user, activityId, answers });
const sign = (user, activityId) => post("/sign-claim", { user, activityId });

test("expone lecciones y preguntas sin las respuestas correctas", async () => {
  const list = await (await fetch(`${base}/activities`)).json();
  assert.deepEqual(list.map((a) => a.id), [1, 2, 3]);

  const res = await fetch(`${base}/activities/1`);
  assert.equal(res.status, 200);
  const text = await res.text();
  assert.ok(!text.includes('"correct"'));
  const data = JSON.parse(text);
  assert.equal(data.questions.length, 4);
  assert.equal(data.attempt, 1);
  assert.ok(Array.isArray(data.lesson));

  assert.equal((await fetch(`${base}/activities/99`)).status, 404);
});

test("no firma si la actividad no fue aprobada", async () => {
  const user = newUser();
  const res = await sign(user, 1);
  assert.equal(res.status, 403);
});

test("respuestas incorrectas no aprueban ni habilitan la firma", async () => {
  const user = newUser();
  const res = await submit(user, 1, wrongAnswers(1));
  assert.equal(res.status, 200);
  const data = await res.json();
  assert.deepEqual(data, { passed: false, attemptsLeft: 2, locked: false }); // sin puntaje
  assert.equal((await sign(user, 1)).status, 403);
});

test("flujo completo: aprobar, ver progreso y recibir una firma EIP-712 válida para el contrato", async () => {
  const user = newUser();
  const passed = await (await submit(user, 1, rightAnswers(1))).json();
  assert.equal(passed.passed, true);

  const prog = await (await fetch(`${base}/progress/${user}`)).json();
  assert.deepEqual(prog.passed, [1]);
  assert.deepEqual(prog.locks, {});

  const res = await sign(user, 1);
  assert.equal(res.status, 200);
  const data = await res.json();
  assert.equal(data.amount, parseEther("10").toString());
  const now = Math.floor(Date.now() / 1000);
  assert.ok(data.deadline > now && data.deadline <= now + 601);

  const recovered = verifyTypedData(
    signer.domain,
    TYPES,
    { user, activityId: 1, amount: BigInt(data.amount), deadline: data.deadline },
    data.signature
  );
  assert.equal(recovered, wallet.address);

  // aprobar una actividad no habilita las demás
  assert.equal((await sign(user, 2)).status, 403);

  // repetir el submit de una actividad ya aprobada no falla ni consume intentos
  const again = await (await submit(user, 1, wrongAnswers(1))).json();
  assert.deepEqual(again, { passed: true, alreadyPassed: true });
});

test("la firma no vale para otro usuario ni otra actividad", async () => {
  const user = newUser();
  await submit(user, 1, rightAnswers(1));
  const data = await (await sign(user, 1)).json();
  const other = newUser();

  const forOther = verifyTypedData(
    signer.domain,
    TYPES,
    { user: other, activityId: 1, amount: BigInt(data.amount), deadline: data.deadline },
    data.signature
  );
  const forActivity2 = verifyTypedData(
    signer.domain,
    TYPES,
    { user, activityId: 2, amount: BigInt(data.amount), deadline: data.deadline },
    data.signature
  );
  assert.notEqual(forOther, wallet.address);
  assert.notEqual(forActivity2, wallet.address);
});

test("cada intento fallido muestra un juego de preguntas distinto y el tercero bloquea 24 h", async () => {
  const user = newUser();
  const textsOf = async () => (await (await fetch(`${base}/activities/3?user=${user}`)).json()).questions.map((q) => q.text);

  const first = await textsOf();
  assert.deepEqual(first, questionsOf(3, 1).map((q) => q.text));

  assert.deepEqual(await (await submit(user, 3, wrongAnswers(3, 1))).json(), { passed: false, attemptsLeft: 2, locked: false });
  const second = await textsOf();
  assert.deepEqual(second, questionsOf(3, 2).map((q) => q.text));
  assert.notDeepEqual(second, first);

  assert.deepEqual(await (await submit(user, 3, wrongAnswers(3, 2))).json(), { passed: false, attemptsLeft: 1, locked: false });
  const third = await textsOf();
  assert.deepEqual(third, questionsOf(3, 3).map((q) => q.text));

  const last = await (await submit(user, 3, wrongAnswers(3, 3))).json();
  assert.equal(last.passed, false);
  assert.equal(last.locked, true);
  assert.equal(last.retryAfterSeconds, 24 * 3600);
  assert.equal(last.score, undefined);

  // bloqueada: nuevo submit => 429, y GET devuelve solo la lección
  const blocked = await submit(user, 3, rightAnswers(3, 1));
  assert.equal(blocked.status, 429);
  assert.ok(Number(blocked.headers.get("retry-after")) >= 1);
  const view = await (await fetch(`${base}/activities/3?user=${user}`)).json();
  assert.equal(view.locked, true);
  assert.deepEqual(view.questions, []);
  assert.ok(view.lesson.length > 0);

  // el bloqueo es solo de esa actividad
  const ok = await (await submit(user, 1, rightAnswers(1, 1))).json();
  assert.equal(ok.passed, true);
  const prog = await (await fetch(`${base}/progress/${user}`)).json();
  assert.ok(prog.locks[3] > 0);
  assert.equal(prog.locks[1], undefined);
});

test("aprobar en el segundo intento con el juego 2 habilita la firma", async () => {
  const user = newUser();
  await submit(user, 2, wrongAnswers(2, 1));
  const res = await (await submit(user, 2, rightAnswers(2, 2))).json();
  assert.deepEqual(res, { passed: true });
  assert.equal((await sign(user, 2)).status, 200);
});

test("valida direcciones, actividades y respuestas", async () => {
  const user = newUser();
  assert.equal((await submit("0x123", 1, rightAnswers(1))).status, 400);
  assert.equal((await submit(user, 99, [0, 0, 0, 0])).status, 400);
  assert.equal((await submit(user, 1.5, [0, 0, 0, 0])).status, 400);
  assert.equal((await submit(user, "1", [0, 0, 0, 0])).status, 400);
  assert.equal((await submit(user, 1, [0, 0])).status, 400);
  assert.equal((await submit(user, 1, [0, 0, 0, 99])).status, 400);
  assert.equal((await submit(user, 1, "0123")).status, 400);

  assert.equal((await sign("0x123", 1)).status, 400);
  assert.equal((await sign(user, 99)).status, 400);
  assert.equal((await post("/sign-claim", { user })).status, 400);
});

test("rechaza JSON inválido o que no sea un objeto", async () => {
  assert.equal((await post("/sign-claim", "{no es json", true)).status, 400);
  assert.equal((await post("/sign-claim", "null", true)).status, 400);
  assert.equal((await post("/submit-answers", "[1,2]", true)).status, 400);
});

test("responde el preflight CORS con el origen permitido", async () => {
  const res = await fetch(`${base}/sign-claim`, { method: "OPTIONS" });
  assert.equal(res.status, 204);
  assert.equal(res.headers.get("access-control-allow-origin"), cfg.allowedOrigin);
  assert.match(res.headers.get("access-control-allow-headers"), /Content-Type/);
});

test("health y rutas desconocidas", async () => {
  const health = await (await fetch(`${base}/health`)).json();
  assert.deepEqual(health, { ok: true, signer: wallet.address });
  assert.equal((await fetch(`${base}/otra-cosa`)).status, 404);
  assert.equal((await fetch(`${base}/progress/0x123`)).status, 404);
});
