const test = require("node:test");
const assert = require("node:assert/strict");
const { ACTIVITIES, ValidationError, findActivity, setFor, publicView, grade } = require("../activities");

test("el contenido es consistente: 3 juegos de 4 preguntas por actividad, aprobación 3 de 4", () => {
  const ids = ACTIVITIES.map((a) => a.id);
  assert.deepEqual(ids, [1, 2, 3]);

  for (const a of ACTIVITIES) {
    assert.ok(a.title.length > 0, `actividad ${a.id}: título`);
    assert.ok(Array.isArray(a.lesson) && a.lesson.length >= 2, `actividad ${a.id}: lección`);
    assert.equal(a.sets.length, 3, `actividad ${a.id}: 3 juegos`);
    assert.equal(a.passScore, 3);
    for (const set of a.sets) {
      assert.equal(set.length, 4, `actividad ${a.id}: 4 preguntas por juego`);
      for (const q of set) {
        assert.ok(q.text.length > 0);
        assert.equal(q.options.length, 4, `actividad ${a.id}: 4 opciones`);
        assert.equal(new Set(q.options).size, 4, `actividad ${a.id}: opciones repetidas`);
        assert.ok(Number.isInteger(q.correct) && q.correct >= 0 && q.correct < 4);
      }
    }
    // los juegos no repiten preguntas entre sí
    const texts = a.sets.flat().map((q) => q.text);
    assert.equal(new Set(texts).size, texts.length, `actividad ${a.id}: preguntas repetidas entre juegos`);
  }
});

test("la vista pública no expone las respuestas y cambia de juego según el intento", () => {
  for (const a of ACTIVITIES) {
    const v1 = publicView(a, 1);
    const v2 = publicView(a, 2);
    const v3 = publicView(a, 3);
    assert.ok(!JSON.stringify([v1, v2, v3]).includes('"correct"'));
    assert.deepEqual(Object.keys(v1.questions[0]).sort(), ["options", "text"]);
    assert.notEqual(v1.questions[0].text, v2.questions[0].text);
    assert.notEqual(v2.questions[0].text, v3.questions[0].text);
    assert.equal(publicView(a).questions[0].text, v1.questions[0].text); // por defecto, juego 1
    assert.equal(setFor(a, 4), a.sets[0]); // más intentos que juegos: vuelve a empezar
  }
});

test("grade aprueba con 3 de 4 y corrige contra el juego del intento", () => {
  const a = findActivity(1);
  const set = setFor(a, 1);
  const right = set.map((q) => q.correct);
  const wrong = set.map((q) => (q.correct + 1) % q.options.length);

  assert.deepEqual(grade(a, 1, right), { score: 4, total: 4, passScore: 3, passed: true });
  assert.equal(grade(a, 1, wrong).passed, false);

  const oneWrong = [...right];
  oneWrong[0] = wrong[0];
  assert.equal(grade(a, 1, oneWrong).passed, true); // 3 de 4 alcanza

  const twoWrong = [wrong[0], wrong[1], right[2], right[3]];
  assert.equal(grade(a, 1, twoWrong).passed, false); // 2 de 4 no alcanza

  // las respuestas del juego 1 no corrigen el juego 2
  const set2 = setFor(a, 2).map((q) => q.correct);
  assert.deepEqual(grade(a, 2, set2).passed, true);
});

test("grade rechaza respuestas incompletas o fuera de rango", () => {
  const a = findActivity(2);
  assert.throws(() => grade(a, 1, [0, 1, 0]), ValidationError);
  assert.throws(() => grade(a, 1, "0123"), ValidationError);
  assert.throws(() => grade(a, 1, [0, 1, 0, 99]), ValidationError);
  assert.throws(() => grade(a, 1, [0, -1, 0, 0]), ValidationError);
  assert.throws(() => grade(a, 1, [0, 1.5, 0, 0]), ValidationError);
  assert.throws(() => grade(a, 1, [0, "1", 0, 0]), ValidationError);
});

test("findActivity devuelve undefined si no existe", () => {
  assert.equal(findActivity(99), undefined);
});
