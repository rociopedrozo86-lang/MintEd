const test = require("node:test");
const assert = require("node:assert/strict");
const { createProgress } = require("../progress");

const USER = "0xAbCdEf0123456789aBcDeF0123456789abcDEF01";
const OTHER = "0x0000000000000000000000000000000000000001";

test("registra actividades aprobadas sin distinguir mayúsculas y devuelve la lista ordenada", () => {
  const p = createProgress();
  assert.equal(p.hasPassed(USER, 1), false);
  p.markPassed(USER, 3);
  p.markPassed(USER.toLowerCase(), 1);
  assert.equal(p.hasPassed(USER, 1), true);
  assert.equal(p.hasPassed(USER, 2), false);
  assert.deepEqual(p.passedList(USER), [1, 3]);
  assert.deepEqual(p.passedList(OTHER), []);
});

test("cada fallo avanza al siguiente juego de preguntas y el tercero bloquea la actividad", () => {
  let t = 0;
  const p = createProgress({ maxAttempts: 3, lockoutMs: 24 * 3600 * 1000, now: () => t });

  assert.equal(p.attemptNumber(USER, 1), 1);
  assert.deepEqual(p.recordFailure(USER, 1), { locked: false, attempt: 1, attemptsLeft: 2 });
  assert.equal(p.attemptNumber(USER, 1), 2);
  assert.deepEqual(p.recordFailure(USER, 1), { locked: false, attempt: 2, attemptsLeft: 1 });
  assert.equal(p.attemptNumber(USER, 1), 3);

  const third = p.recordFailure(USER, 1);
  assert.deepEqual(third, { locked: true, attempt: 3, attemptsLeft: 0, retryAfterSeconds: 24 * 3600 });
  assert.equal(p.lockRemainingSeconds(USER, 1), 24 * 3600);
  assert.equal(p.attemptNumber(USER, 1), 1); // el contador vuelve a cero
});

test("el bloqueo es por actividad y por usuario, y vence a las 24 h", () => {
  let t = 0;
  const p = createProgress({ maxAttempts: 1, lockoutMs: 1000, now: () => t });
  p.recordFailure(USER, 1);

  assert.equal(p.lockRemainingSeconds(USER, 1), 1);
  assert.equal(p.lockRemainingSeconds(USER, 2), 0); // otra actividad
  assert.equal(p.lockRemainingSeconds(OTHER, 1), 0); // otro usuario

  t = 1001;
  assert.equal(p.lockRemainingSeconds(USER, 1), 0);
});

test("aprobar una actividad no se ve afectado por el bloqueo de otra", () => {
  const p = createProgress({ maxAttempts: 1 });
  p.markPassed(USER, 1);
  p.recordFailure(USER, 2);
  assert.deepEqual(p.passedList(USER), [1]);
});

test("aprobar reinicia el contador de fallos", () => {
  const p = createProgress();
  p.recordFailure(USER, 1);
  p.markPassed(USER, 1);
  assert.equal(p.attemptNumber(USER, 1), 1);
});

test("summary resume aprobadas, intento actual y bloqueos", () => {
  const p = createProgress({ maxAttempts: 1, lockoutMs: 5000, now: () => 0 });
  p.markPassed(USER, 1);
  p.recordFailure(USER, 2);
  assert.deepEqual(p.summary(USER, [1, 2, 3]), {
    passed: [1],
    attempts: { 1: 1, 2: 1, 3: 1 },
    locks: { 2: 5 },
    maxAttempts: 1,
  });
});
