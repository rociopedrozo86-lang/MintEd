/**
 * Estado en memoria por usuario: actividades aprobadas, fallos y bloqueo POR ACTIVIDAD.
 * Se pierde al reiniciar el servidor: el usuario simplemente rehace el quiz.
 *
 * Regla de intentos:
 * - Cada actividad admite `maxAttempts` intentos seguidos (3 por defecto). El intento N usa el juego de preguntas N.
 * - Al fallar el último, esa actividad queda bloqueada `lockoutMs` (24 h por defecto; 0 = sin bloqueo).
 *   Pasado el bloqueo, el contador vuelve a cero y el usuario empieza de nuevo desde el juego 1, con la lección a la vista.
 * - Las demás actividades no se ven afectadas.
 * - Lo que ya se reclamó on-chain (`claimed` en MintXP) es permanente y nunca se deshace: por eso el "reinicio"
 *   es un bloqueo por actividad y no un borrado del progreso.
 */
function createProgress({ maxAttempts = 3, lockoutMs = 24 * 60 * 60 * 1000, now = Date.now } = {}) {
  const users = new Map(); // usuario (minúsculas) -> { passed: Set, failures: Map, lockedUntil: Map }
  const norm = (user) => user.toLowerCase();
  const state = (user) => {
    const key = norm(user);
    if (!users.has(key)) users.set(key, { passed: new Set(), failures: new Map(), lockedUntil: new Map() });
    return users.get(key);
  };

  const api = {
    maxAttempts,

    hasPassed(user, activityId) {
      return users.get(norm(user))?.passed.has(activityId) ?? false;
    },

    passedList(user) {
      return [...(users.get(norm(user))?.passed ?? [])].sort((a, b) => a - b);
    },

    /** Segundos que faltan para que termine el bloqueo de esa actividad (0 si no está bloqueada). */
    lockRemainingSeconds(user, activityId) {
      const until = users.get(norm(user))?.lockedUntil.get(activityId) ?? 0;
      const left = until - now();
      return left > 0 ? Math.ceil(left / 1000) : 0;
    },

    /** Número del próximo intento (1, 2, 3) para esa actividad. */
    attemptNumber(user, activityId) {
      return (users.get(norm(user))?.failures.get(activityId) ?? 0) + 1;
    },

    markPassed(user, activityId) {
      const s = state(user);
      s.passed.add(activityId);
      s.failures.delete(activityId);
      s.lockedUntil.delete(activityId);
    },

    /** Registra un fallo. Si era el último intento, bloquea la actividad y reinicia el contador. */
    recordFailure(user, activityId) {
      const s = state(user);
      const attempt = (s.failures.get(activityId) ?? 0) + 1;
      if (attempt < maxAttempts) {
        s.failures.set(activityId, attempt);
        return { locked: false, attempt, attemptsLeft: maxAttempts - attempt };
      }
      s.failures.delete(activityId);
      if (lockoutMs > 0) s.lockedUntil.set(activityId, now() + lockoutMs);
      return { locked: lockoutMs > 0, attempt, attemptsLeft: 0, retryAfterSeconds: Math.ceil(lockoutMs / 1000) };
    },

    /** Resumen para el front: aprobadas y, por actividad, intento actual y bloqueo vigente. */
    summary(user, activityIds) {
      const attempts = {};
      const locks = {};
      for (const id of activityIds) {
        attempts[id] = api.attemptNumber(user, id);
        const left = api.lockRemainingSeconds(user, id);
        if (left > 0) locks[id] = left;
      }
      return { passed: api.passedList(user), attempts, locks, maxAttempts };
    },
  };
  return api;
}

module.exports = { createProgress };
