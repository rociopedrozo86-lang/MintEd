// Contenido educativo del learning path 1: "Fundamentos de Web3".
// Los ids deben coincidir con CONFIG.activities del front y con createPath(1, [1, 2, 3]) del deploy.
//
// Cada actividad tiene una lección y TRES juegos de CUATRO preguntas (`sets`); se aprueba con 3 de 4. El intento N usa el juego N:
// el segundo y el tercer intento muestran preguntas distintas. El juego 1 es el que se ve al empezar.
// `correct` es el índice de la opción correcta y NUNCA se envía al front.

const ACTIVITIES = [
  {
    id: 1,
    title: "Tu primera wallet",
    passScore: 3,
    lesson: [
      "Una wallet no guarda tus tokens: guarda las claves que te permiten mover lo que tenés registrado en la blockchain.",
      "Tu dirección (0x...) es pública, como tu CBU: podés compartirla para que te envíen fondos. Tu clave privada, o la frase de recuperación de 12 o 24 palabras, es secreta: quien la tiene controla todo lo que hay en la cuenta. Nadie legítimo te la va a pedir.",
      "No existe la opción de «olvidé mi contraseña»: si perdés la frase y el dispositivo, perdés el acceso.",
      "Para practicar sin riesgo existen las testnets, como Sepolia. Usan ETH de prueba, que no tiene valor y se consigue gratis en los faucets.",
    ],
    sets: [
      [
        {
          text: "¿Qué podés compartir sin riesgo con otra persona para que te envíe tokens?",
          options: ["Tu frase de recuperación", "Tu clave privada", "Tu dirección pública", "La contraseña de tu wallet"],
          correct: 2,
        },
        {
          text: "Si perdés tu frase de recuperación y también tu dispositivo, ¿qué pasa?",
          options: [
            "Podés pedirle a la blockchain que la restablezca",
            "Probablemente pierdas el acceso a tus fondos para siempre",
            "El soporte de Ethereum te envía una nueva",
            "Se recupera con tu email",
          ],
          correct: 1,
        },
        {
          text: "¿Para qué sirve una testnet como Sepolia?",
          options: [
            "Para invertir con dinero real",
            "Para minar bitcoin",
            "Para practicar con ETH de prueba que no tiene valor",
            "Para guardar contraseñas",
          ],
          correct: 2,
        },
        {
          text: "¿Por qué la frase de recuperación es tan sensible?",
          options: [
            "Quien la tiene puede controlar todos los fondos de la cuenta",
            "Es lo que se paga como gas",
            "Es pública en la blockchain",
            "Caduca cada 30 días",
          ],
          correct: 0,
        },
      ],
      [
        {
          text: "¿Qué guarda realmente una wallet?",
          options: [
            "Tus tokens dentro de una app",
            "Una copia de tu documento de identidad",
            "Las claves que permiten mover lo que tenés registrado en la blockchain",
            "Tu historial de navegación",
          ],
          correct: 2,
        },
        {
          text: "Alguien que dice ser de soporte te pide tu frase de recuperación para «verificar tu cuenta». ¿Qué corresponde hacer?",
          options: [
            "Enviársela, porque es soporte oficial",
            "No compartirla con nadie: ningún servicio legítimo la pide",
            "Enviarle solo la mitad de las palabras",
            "Compartirla solo si te lo piden por correo",
          ],
          correct: 1,
        },
        {
          text: "¿Qué característica tiene el ETH de una red de prueba como Sepolia?",
          options: ["Se compra en exchanges", "Se puede cambiar por pesos", "Solo lo reciben los validadores", "Es gratis y no tiene valor económico"],
          correct: 3,
        },
        {
          text: "¿Dónde conviene guardar la frase de recuperación?",
          options: [
            "En una captura de pantalla en la nube",
            "En un chat con vos mismo",
            "Anotada en papel y guardada en un lugar seguro, fuera de línea",
            "En un mensaje a un amigo",
          ],
          correct: 2,
        },
      ],
      [
        {
          text: "La dirección de tu wallet (0x...) se parece a:",
          options: [
            "Tu clave del cajero automático",
            "Tu PIN de la tarjeta",
            "Tu CBU: la podés compartir para recibir fondos",
            "El código de seguridad de la tarjeta",
          ],
          correct: 2,
        },
        {
          text: "¿Por qué una wallet no tiene la opción «olvidé mi contraseña» como una app tradicional?",
          options: [
            "Porque es un error de diseño",
            "Porque no hay una empresa central que guarde tus claves y pueda restablecerlas",
            "Porque la contraseña se guarda en Sepolia",
            "Porque solo se usa una vez",
          ],
          correct: 1,
        },
        {
          text: "¿Cómo se consigue ETH de prueba para practicar en Sepolia?",
          options: [
            "Pidiéndolo en un faucet",
            "Comprándolo con tarjeta de crédito en la wallet",
            "Minándolo con el celular",
            "Transfiriéndolo desde Ethereum principal",
          ],
          correct: 0,
        },
        {
          text: "Si alguien conoce tu dirección pública (0x...), ¿qué puede hacer?",
          options: [
            "Vaciar tu cuenta",
            "Enviarte fondos, pero no moverlos desde tu cuenta",
            "Ver tu frase de recuperación",
            "Cambiar tu contraseña",
          ],
          correct: 1,
        },
      ],
    ],
  },
  {
    id: 2,
    title: "Firmar una transacción",
    passScore: 3,
    lesson: [
      "Para cambiar algo en la blockchain enviás una transacción y la firmás con tu clave privada. La firma prueba que fuiste vos quien la autorizó, sin revelar la clave.",
      "Cada transacción paga gas: una tarifa en ETH para quienes validan la red. Si la transacción falla durante su ejecución (se dice que «revierte»), igual se paga el gas que se consumió hasta ese punto.",
      "Leer datos de la blockchain, como consultar un saldo, no requiere firmar ni paga gas.",
      "Una transacción confirmada no se puede deshacer. Por eso conviene leer qué estás aprobando antes de tocar «Confirmar» en la wallet.",
    ],
    sets: [
      [
        {
          text: "¿Qué demuestra la firma de una transacción?",
          options: [
            "Que tenés ETH suficiente",
            "Que quien la envía controla la clave privada de la cuenta, sin revelarla",
            "Que la transacción va a salir bien",
            "Que el contrato con el que interactuás es seguro",
          ],
          correct: 1,
        },
        {
          text: "Una transacción revierte mientras se ejecuta. ¿Qué pasa con el gas?",
          options: ["Se devuelve completo", "No se cobra nada", "Se paga igual el gas consumido", "Se cobra el doble"],
          correct: 2,
        },
        {
          text: "¿Cuál de estas acciones NO requiere firmar ni pagar gas?",
          options: ["Transferir tokens", "Aprobar un gasto (approve)", "Consultar tu saldo", "Reclamar una recompensa"],
          correct: 2,
        },
        {
          text: "¿Qué se necesita para enviar una transacción?",
          options: [
            "Aprobación de MintEd",
            "Firmarla con tu clave privada y tener ETH para el gas",
            "Un correo de confirmación",
            "Que otro usuario la valide primero",
          ],
          correct: 1,
        },
      ],
      [
        {
          text: "¿Quién recibe el gas que pagás por una transacción?",
          options: ["MintEd", "La wallet que usás", "El destinatario de la transacción", "Quienes validan la red"],
          correct: 3,
        },
        {
          text: "Una transacción ya confirmada en la blockchain, ¿se puede deshacer?",
          options: [
            "No: una vez confirmada no se puede deshacer",
            "Sí, pidiendo la anulación al soporte de la wallet",
            "Sí, durante las primeras 24 horas",
            "Solo si se paga más gas",
          ],
          correct: 0,
        },
        {
          text: "Antes de tocar «Confirmar» en la wallet, ¿qué conviene hacer?",
          options: [
            "Confirmar rápido, porque la solicitud vence",
            "Cerrar y volver a abrir la wallet",
            "Leer qué se está aprobando y a quién",
            "Pedirle a un desconocido que confirme por vos",
          ],
          correct: 2,
        },
        {
          text: "Una transacción revirtió. ¿Qué conviene hacer?",
          options: [
            "Reintentar sin revisar nada",
            "Revisar el motivo del error antes de reenviar, porque cada intento puede costar gas",
            "Compartir tu frase con el soporte",
            "Esperar a que se devuelva el gas",
          ],
          correct: 1,
        },
      ],
      [
        {
          text: "¿Qué es el gas?",
          options: [
            "Un impuesto que cobra la wallet",
            "Una tarifa en ETH que se paga por ejecutar una operación en la red",
            "Un token que entrega MintEd",
            "El saldo mínimo para tener una cuenta",
          ],
          correct: 1,
        },
        {
          text: "Tu clave privada firma una transacción. ¿Qué queda a la vista de todos?",
          options: [
            "Tu clave privada",
            "Tu frase de recuperación",
            "La firma, que prueba que autorizaste la operación, pero no tu clave",
            "Tu contraseña",
          ],
          correct: 2,
        },
        {
          text: "Si no tenés ETH suficiente para pagar el gas, ¿qué pasa?",
          options: [
            "La red te presta ETH",
            "Se cobra de tus MXP",
            "Se ejecuta igual, sin costo",
            "La transacción no se puede ejecutar hasta que tengas ETH suficiente",
          ],
          correct: 3,
        },
        {
          text: "¿Qué diferencia hay entre tu dirección y tu clave privada?",
          options: [
            "Son lo mismo",
            "La dirección es pública y sirve para recibir; la clave privada es secreta y sirve para firmar",
            "La clave privada es pública",
            "La dirección sirve para firmar",
          ],
          correct: 1,
        },
      ],
    ],
  },
  {
    id: 3,
    title: "Interactuar con un contrato",
    passScore: 3,
    lesson: [
      "Un smart contract es código desplegado en una dirección de la blockchain. Sus reglas se ejecutan tal como fueron escritas, sin que nadie pueda cambiarlas a mitad de camino.",
      "Las funciones de lectura (view) consultan el estado sin modificarlo y se pueden llamar sin gas. Las de escritura modifican el estado y requieren una transacción firmada con gas.",
      "Los eventos son registros públicos que el contrato emite cuando pasa algo importante. Las apps los leen para armar historiales, y vos podés verlos en un explorador como Etherscan.",
      "En MintEd, reclamar MXP y reclamar la credencial son llamadas de escritura a contratos en Sepolia: cada una genera una transacción con su hash.",
    ],
    sets: [
      [
        {
          text: "¿Cuál es la diferencia entre una función de lectura (view) y una de escritura?",
          options: [
            "Las de lectura modifican el estado y las de escritura no",
            "Las de lectura solo consultan y se llaman sin gas; las de escritura modifican el estado y requieren una transacción",
            "Solo las de escritura se ven en Etherscan",
            "No hay ninguna diferencia",
          ],
          correct: 1,
        },
        {
          text: "¿Para qué sirven los eventos de un contrato?",
          options: [
            "Para dejar un registro público de lo ocurrido que las apps pueden leer",
            "Para pagar menos gas en cualquier función",
            "Para cambiar el dueño del contrato",
            "Para borrar transacciones",
          ],
          correct: 0,
        },
        {
          text: "Cuando reclamás MXP en MintEd, ¿qué estás haciendo?",
          options: [
            "Una lectura gratuita de tu saldo",
            "Una transferencia de ETH a otra persona",
            "Una transacción de escritura sobre el contrato MintXP, firmada por vos y con gas",
            "Descargar un archivo del backend",
          ],
          correct: 2,
        },
        {
          text: "¿Qué es el hash de una transacción?",
          options: [
            "Su identificador único, para consultarla en un explorador",
            "La contraseña del contrato",
            "El saldo restante",
            "La clave del firmante",
          ],
          correct: 0,
        },
      ],
      [
        {
          text: "¿Dónde vive un smart contract?",
          options: ["En el teléfono del usuario", "En el servidor de la plataforma", "En una dirección de la blockchain", "Dentro de la wallet"],
          correct: 2,
        },
        {
          text: "¿Qué identifica a una transacción ya enviada, para poder consultarla después en un explorador?",
          options: ["Su hash", "El nombre del usuario", "La fecha de emisión del token", "El saldo de la wallet"],
          correct: 0,
        },
        {
          text: "¿Para qué se usa un explorador como Etherscan?",
          options: [
            "Para guardar claves privadas",
            "Para modificar contratos desplegados",
            "Para recuperar fondos enviados por error",
            "Para consultar transacciones, contratos y eventos públicos",
          ],
          correct: 3,
        },
        {
          text: "¿Qué significa que un contrato esté «desplegado» en Sepolia?",
          options: [
            "Que su código ya está publicado en una dirección de esa red",
            "Que fue aprobado por Ethereum principal",
            "Que está guardado en tu wallet",
            "Que solo su autor puede verlo",
          ],
          correct: 0,
        },
      ],
      [
        {
          text: "Las reglas de un contrato «se ejecutan tal como fueron escritas». ¿Qué significa?",
          options: [
            "Que el desarrollador puede cambiarlas cuando quiera",
            "Que requieren aprobación manual de la plataforma",
            "Que el código se ejecuta según lo programado, sin que nadie pueda cambiarlo a mitad de camino",
            "Que solo funcionan en horario laboral",
          ],
          correct: 2,
        },
        {
          text: "Consultar el saldo de MXP de una dirección es una operación:",
          options: [
            "De escritura: requiere gas",
            "De lectura (view): no modifica el estado ni requiere gas",
            "Que solo puede hacer el dueño del contrato",
            "Que necesita tu clave privada",
          ],
          correct: 1,
        },
        {
          text: "Un contrato emite un evento cuando ocurre algo importante. ¿Qué podés hacer con ese evento?",
          options: [
            "Borrarlo para ocultar la operación",
            "Usarlo para revertir la transacción",
            "Consultarlo en un explorador como registro público de lo ocurrido",
            "Convertirlo en gas",
          ],
          correct: 2,
        },
        {
          text: "¿Cuál de estas operaciones modifica el estado de un contrato?",
          options: [
            "Consultar un saldo",
            "Leer un evento pasado",
            "Ver el código en Etherscan",
            "Reclamar MXP con una transacción firmada",
          ],
          correct: 3,
        },
      ],
    ],
  },
];

class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.status = 400;
  }
}

function findActivity(id) {
  return ACTIVITIES.find((a) => a.id === id);
}

/** Juego de preguntas que corresponde al intento N (1, 2, 3...). Si hay más intentos que juegos, vuelve a empezar. */
function setFor(activity, attempt) {
  const n = Number.isInteger(attempt) && attempt >= 1 ? attempt : 1;
  return activity.sets[(n - 1) % activity.sets.length];
}

/** Versión para el front: el juego del intento, sin las respuestas correctas. */
function publicView(activity, attempt = 1) {
  return {
    id: activity.id,
    title: activity.title,
    lesson: activity.lesson,
    passScore: activity.passScore,
    questions: setFor(activity, attempt).map(({ text, options }) => ({ text, options })),
  };
}

/** Corrige las respuestas contra el juego del intento. `answers` es el índice elegido para cada pregunta. */
function grade(activity, attempt, answers) {
  const questions = setFor(activity, attempt);
  if (!Array.isArray(answers) || answers.length !== questions.length) {
    throw new ValidationError("Respondé todas las preguntas");
  }
  let score = 0;
  questions.forEach((q, i) => {
    const a = answers[i];
    if (!Number.isInteger(a) || a < 0 || a >= q.options.length) {
      throw new ValidationError("Respuesta inválida");
    }
    if (a === q.correct) score++;
  });
  return {
    score,
    total: questions.length,
    passScore: activity.passScore,
    passed: score >= activity.passScore,
  };
}

module.exports = { ACTIVITIES, ValidationError, findActivity, setFor, publicView, grade };
