const http = require("node:http");
const { isAddress, getAddress, parseEther, ZeroAddress } = require("ethers");
const { makeSigner } = require("./sign");
const { ACTIVITIES, findActivity, publicView, grade } = require("./activities");
const { createProgress } = require("./progress");

const MAX_BODY_BYTES = 4096;

function httpError(status, message) {
  return Object.assign(new Error(message), { status });
}

/**
 * Crea el servidor HTTP del firmante.
 * Flujo: el usuario lee la lección, envía respuestas a /submit-answers y, si aprueba,
 * /sign-claim le devuelve la firma EIP-712 para reclamar MXP en el contrato.
 */
function createServer(cfg) {
  const signer = makeSigner(cfg);
  const progress = cfg.progress || createProgress();

  const cors = {
    "Access-Control-Allow-Origin": cfg.allowedOrigin,
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "600",
    Vary: "Origin",
  };

  function send(res, status, body, extraHeaders = {}) {
    res.writeHead(status, { "Content-Type": "application/json", ...cors, ...extraHeaders });
    res.end(body === undefined ? undefined : JSON.stringify(body));
  }

  function readJson(req) {
    return new Promise((resolve, reject) => {
      let size = 0;
      const chunks = [];
      req.on("data", (c) => {
        size += c.length;
        if (size > MAX_BODY_BYTES) return reject(httpError(413, "Body demasiado grande"));
        chunks.push(c);
      });
      req.on("end", () => {
        let parsed;
        try {
          parsed = JSON.parse(Buffer.concat(chunks).toString("utf8"));
        } catch {
          return reject(httpError(400, "JSON inválido"));
        }
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
          return reject(httpError(400, "El body debe ser un objeto JSON"));
        }
        resolve(parsed);
      });
      req.on("error", reject);
    });
  }

  function requireUser(user) {
    if (typeof user !== "string" || !isAddress(user)) throw httpError(400, "user debe ser una dirección válida");
    return getAddress(user);
  }

  function requireActivity(activityId) {
    const activity = Number.isInteger(activityId) ? findActivity(activityId) : undefined;
    if (!activity) throw httpError(400, "activityId inválido");
    return activity;
  }

  const server = http.createServer(async (req, res) => {
    try {
      if (req.method === "OPTIONS") return send(res, 204);

      let pathname;
      try {
        pathname = new URL(req.url, "http://localhost").pathname;
      } catch {
        throw httpError(400, "URL inválida");
      }

      if (req.method === "GET") {
        if (pathname === "/health") return send(res, 200, { ok: true, signer: signer.address });

        if (pathname === "/activities") {
          return send(res, 200, ACTIVITIES.map((a) => ({ id: a.id, title: a.title, questions: a.sets[0].length })));
        }

        // Con ?user=0x... devuelve el juego de preguntas que corresponde al intento de ese usuario.
        // Si la actividad está bloqueada, devuelve solo la lección (sin preguntas) y el tiempo restante.
        let m = pathname.match(/^\/activities\/(\d+)$/);
        if (m) {
          const activity = findActivity(Number(m[1]));
          if (!activity) throw httpError(404, "Actividad no encontrada");
          const userParam = new URL(req.url, "http://localhost").searchParams.get("user");
          const user = userParam ? requireUser(userParam) : undefined;
          const view = publicView(activity, user ? progress.attemptNumber(user, activity.id) : 1);
          const locked = user ? progress.lockRemainingSeconds(user, activity.id) : 0;
          if (locked > 0) {
            return send(res, 200, { ...view, questions: [], locked: true, retryAfterSeconds: locked });
          }
          return send(res, 200, { ...view, attempt: user ? progress.attemptNumber(user, activity.id) : 1, maxAttempts: progress.maxAttempts });
        }

        m = pathname.match(/^\/progress\/(0x[0-9a-fA-F]{40})$/);
        if (m) return send(res, 200, progress.summary(m[1], ACTIVITIES.map((a) => a.id)));
      }

      if (req.method === "POST" && pathname === "/submit-answers") {
        const body = await readJson(req);
        const user = requireUser(body.user);
        const activity = requireActivity(body.activityId);

        if (progress.hasPassed(user, activity.id)) {
          return send(res, 200, { passed: true, alreadyPassed: true });
        }

        const locked = progress.lockRemainingSeconds(user, activity.id);
        if (locked > 0) {
          return send(
            res,
            429,
            { error: "Actividad bloqueada. Repasá la lección y volvé a intentarlo más tarde.", retryAfterSeconds: locked },
            { "Retry-After": String(locked) }
          );
        }

        const attempt = progress.attemptNumber(user, activity.id);
        const result = grade(activity, attempt, body.answers);
        if (result.passed) {
          progress.markPassed(user, activity.id);
          console.log(`[submit-answers] user=${user} activityId=${activity.id} attempt=${attempt} passed`);
          return send(res, 200, { passed: true });
        }

        // El puntaje no se devuelve cuando falla: así no se puede ir descartando opciones entre intentos.
        const failure = progress.recordFailure(user, activity.id);
        console.log(`[submit-answers] user=${user} activityId=${activity.id} attempt=${attempt} failed locked=${failure.locked}`);
        return send(res, 200, {
          passed: false,
          attemptsLeft: failure.attemptsLeft,
          locked: failure.locked,
          ...(failure.locked ? { retryAfterSeconds: failure.retryAfterSeconds } : {}),
        });
      }

      if (req.method === "POST" && pathname === "/sign-claim") {
        const body = await readJson(req);
        const user = requireUser(body.user);
        const activity = requireActivity(body.activityId);

        if (!progress.hasPassed(user, activity.id)) {
          throw httpError(403, "Primero tenés que aprobar la actividad");
        }

        const result = await signer.signClaim({ user, activityId: activity.id });
        console.log(`[sign-claim] user=${user} activityId=${activity.id}`);
        return send(res, 200, result);
      }

      throw httpError(404, "No encontrado");
    } catch (e) {
      const status = e.status || 500;
      if (status === 500) console.error(e);
      return send(res, status, { error: status === 500 ? "Error interno" : e.message });
    }
  });

  return { server, signer };
}

function configFromEnv(env = process.env) {
  const { SIGNER_PRIVATE_KEY, MINTXP_ADDRESS } = env;
  if (!SIGNER_PRIVATE_KEY) throw new Error("Falta SIGNER_PRIVATE_KEY en .env");
  if (!MINTXP_ADDRESS || !isAddress(MINTXP_ADDRESS) || MINTXP_ADDRESS === ZeroAddress) {
    throw new Error("Falta MINTXP_ADDRESS (dirección del contrato MintXP desplegado) en .env");
  }
  return {
    privateKey: SIGNER_PRIVATE_KEY,
    chainId: Number(env.CHAIN_ID || 11155111),
    mintXP: getAddress(MINTXP_ADDRESS),
    amount: parseEther(env.AMOUNT_PER_ACTIVITY || "10"),
    deadlineSeconds: Number(env.DEADLINE_SECONDS || 600),
    allowedOrigin: env.ALLOWED_ORIGIN || "http://localhost:8000",
    progress: createProgress({
      maxAttempts: Number(env.MAX_ATTEMPTS || 3),
      lockoutMs: Number(env.LOCKOUT_HOURS ?? 24) * 60 * 60 * 1000,
    }),
  };
}

if (require.main === module) {
  const cfg = configFromEnv();
  const { server, signer } = createServer(cfg);
  const port = Number(process.env.PORT || 3001);
  server.listen(port, () => {
    console.log(`Backend escuchando en http://localhost:${port}`);
    console.log(`Dirección del firmante: ${signer.address}`);
    console.log("Esta dirección debe ser el claimSigner de MintXP (CLAIM_SIGNER_ADDRESS al desplegar o setClaimSigner).");
    console.log(`CORS permitido para: ${cfg.allowedOrigin}`);
  });
}

module.exports = { createServer, configFromEnv };
