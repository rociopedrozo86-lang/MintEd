# Mint Mind — Backend (contenido y firmante de claims)

Dos responsabilidades:

1. **Contenido educativo**: lecciones y quiz de las 3 actividades del learning path (`activities.js`). Las respuestas correctas viven solo en el servidor.
2. **Firmante**: si el usuario aprobó una actividad, firma el mensaje EIP-712 `Claim(user, activityId, amount, deadline)` con el que reclama MXP en `MintXP.claimXP`.

## Uso

Requiere Node 20.6 o superior.

```bash
npm install
cp .env.example .env     # completar SIGNER_PRIVATE_KEY y MINTXP_ADDRESS
npm test                 # no necesita red ni contratos
npm start
```

Al arrancar imprime la **dirección del firmante**: tiene que ser la misma que `claimSigner` en `MintXP` (se define con `CLAIM_SIGNER_ADDRESS` al desplegar, o después con `setClaimSigner`). Si no coincide, todos los claims revierten con `BadSignature`.

## Flujo

```
front: GET /activities/:id            lección + preguntas (sin respuestas correctas)
front: POST /submit-answers           el servidor corrige; si aprueba, lo registra
front: POST /sign-claim               solo firma si la actividad fue aprobada
front: MintXP.claimXP(...)            transacción on-chain firmada por el usuario
```

## API

| Método y ruta | Descripción |
|---|---|
| `GET /activities` | Lista `[{ id, title, questions }]` |
| `GET /activities/:id?user=0x...` | `{ id, title, lesson[], passScore, attempt, maxAttempts, questions[{ text, options[] }] }`. Con `user`, las preguntas son las del juego que corresponde a su intento (1, 2 o 3). Si la actividad está bloqueada devuelve `{ locked: true, retryAfterSeconds, questions: [] }` con la lección |
| `GET /progress/:address` | `{ passed: [1, 2], attempts: { "1": 1, ... }, locks: { "3": 81200 }, maxAttempts }`: aprobadas, intento actual por actividad y segundos de bloqueo vigentes |
| `POST /submit-answers` | Body `{ user, activityId, answers: [2, 1, 2, 0] }` (índice elegido por pregunta). Si aprueba: `{ passed: true }`. Si falla: `{ passed: false, attemptsLeft, locked, retryAfterSeconds? }`, **sin puntaje**. Si ya estaba aprobada: `{ passed: true, alreadyPassed: true }` |
| `POST /sign-claim` | Body `{ user, activityId }`. Devuelve `{ amount, deadline, signature }`; 403 si la actividad no fue aprobada |
| `GET /health` | `{ ok, signer }` |

Errores: 400 (datos inválidos), 403 (actividad no aprobada), 404, 413 (body grande), 429 (actividad bloqueada por 3 fallos; incluye `Retry-After` y `retryAfterSeconds`).

## Intentos de quiz

- Cada actividad tiene **3 juegos de 4 preguntas**. El intento 1 usa el juego 1, el 2 usa el juego 2 y el 3 usa el juego 3: las preguntas cambian en el segundo y el tercer intento.
- Se aprueba con **3 de 4** (`passScore`).
- Cuando falla, el backend **no devuelve el puntaje**, solo cuántos intentos quedan.
- Tras el **tercer fallo**, esa actividad queda bloqueada **24 horas** (`LOCKOUT_HOURS`). El front muestra la lección para repasar. Al vencer el bloqueo, el usuario vuelve a empezar desde el juego 1.
- El bloqueo es por actividad: no afecta a las demás ni a lo ya reclamado on-chain. `claimed` en `MintXP` es permanente y no se puede reiniciar, por eso el "reinicio" se resuelve acá, off-chain.
- Con 4 opciones por pregunta, adivinar 3 de 4 al azar tiene 5,1 % de éxito por intento (14,5 % en los tres intentos).

## Editar el contenido

Todo está en `activities.js`. Cada actividad tiene `id`, `title`, `lesson` (lista de párrafos), `passScore` y `sets` (3 juegos, cada uno con 4 preguntas con `text`, `options` y `correct` = índice de la opción correcta). Reglas para no romper nada:

- Los `id` tienen que coincidir con `CONFIG.activities` del front y con el `createPath` del deploy de contratos (hoy `[1, 2, 3]`).
- Si agregan actividades, hay que crear un path nuevo en el contrato: los paths ya creados no se pueden modificar.
- `npm test` controla que cada actividad tenga 3 juegos de 4 preguntas sin repetirse, con una respuesta correcta válida, y que la vista pública no filtre `correct`.

## Orden recomendado para el primer deploy

1. Crear una wallet nueva para el firmante y guardar su clave solo en el `.env` del backend.
2. Desplegar los contratos con `CLAIM_SIGNER_ADDRESS` = dirección de esa wallet.
3. Poner la dirección de `MintXP` en `MINTXP_ADDRESS` y levantar el backend.
4. Poner las direcciones de los contratos en `front/config.js` y servir el front en el origen configurado en `ALLOWED_ORIGIN`.

## Seguridad y límites

- La clave del firmante controla la emisión de MXP: nunca debe subirse al repo ni usarse en otra wallet.
- Cada firma vale para un usuario, una actividad, un monto y hasta su `deadline`; el contrato impide el doble claim.
- Los intentos de quiz están limitados: 3 por actividad, con preguntas distintas en cada uno, sin puntaje al fallar y 24 h de bloqueo después del tercer fallo. Eso frena el ensayo y error sobre una misma wallet.
- El progreso se guarda en memoria: si se reinicia el servidor, los usuarios rehacen el quiz.
- **No resuelve el sybil**: una misma persona puede usar varias wallets, cada una con sus propios intentos. Es un límite conocido del MVP y conviene mencionarlo en el análisis de riesgos.
- Sin autenticación de usuarios ni protección contra abuso de red: no exponerlo públicamente tal como está.
