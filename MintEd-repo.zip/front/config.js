// Configuración del front. Completar las direcciones después del deploy en Sepolia.
export const CONFIG = {
  chainId: 11155111,
  chainName: "Sepolia",
  explorer: "https://sepolia.etherscan.io",
  rpcUrl: "https://rpc.sepolia.org",

  // TODO: reemplazar por las direcciones desplegadas
  mintXP: "0x0000000000000000000000000000000000000000",
  mintCredential: "0x0000000000000000000000000000000000000000",

  // Backend de contenido y firmas (Persona C). Endpoints que usa el front:
  //   GET  /progress/:address     -> { passed: [1, 2] }
  //   GET  /activities/:id        -> { title, lesson[], passScore, questions[{ text, options[] }] }
  //   POST /submit-answers        body { user, activityId, answers: [idx, ...] } -> { passed, score, total, passScore }
  //   POST /sign-claim            body { user, activityId } -> { amount, deadline, signature }
  // Los ids de actividad deben coincidir con backend/activities.js y con createPath() del deploy.
  backendUrl: "http://localhost:3001",

  pathId: 1,
  activities: [
    { id: 1, title: "Tu primera wallet", desc: "Creá una wallet y conectala a Sepolia." },
    { id: 2, title: "Firmar una transacción", desc: "Entendé qué firmás y qué es el gas." },
    { id: 3, title: "Interactuar con un contrato", desc: "Llamá a una función de un smart contract." },
  ],
};
