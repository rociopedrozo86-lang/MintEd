import { ethers } from "https://cdn.jsdelivr.net/npm/ethers@6.13.4/+esm";
import { CONFIG } from "./config.js";
import { MINTXP_ABI, CREDENTIAL_ABI } from "./abis.js";

const $ = (id) => document.getElementById(id);
const ZERO = "0x0000000000000000000000000000000000000000";

const state = {
  provider: null,
  signer: null,
  address: null,
  xp: null,
  cred: null,
  decimals: 18,
  symbol: "MXP",
  busy: false,
};

// ---------- utilidades ----------
const short = (a) => `${a.slice(0, 6)}…${a.slice(-4)}`;
const fmt = (v) =>
  Number(ethers.formatUnits(v, state.decimals)).toLocaleString("es-AR", { maximumFractionDigits: 4 });

function showBanner(msg, isError = false) {
  const b = $("banner");
  b.textContent = msg;
  b.classList.toggle("error", isError);
  b.classList.remove("hidden");
}
function hideBanner() {
  $("banner").classList.add("hidden");
}

function friendlyError(e) {
  if (e?.code === "ACTION_REJECTED") return "Rechazaste la operación en la wallet.";
  if (e?.code === "INSUFFICIENT_FUNDS") return "No tenés ETH suficiente para pagar el gas. Pedí ETH en un faucet de Sepolia.";
  return e?.reason || e?.shortMessage || e?.info?.error?.message || e?.message || "Error desconocido";
}

function contractsConfigured() {
  return CONFIG.mintXP !== ZERO && CONFIG.mintCredential !== ZERO;
}

// ---------- conexión ----------
async function ensureSepolia() {
  const hexId = "0x" + CONFIG.chainId.toString(16);
  try {
    await window.ethereum.request({ method: "wallet_switchEthereumChain", params: [{ chainId: hexId }] });
  } catch (e) {
    if (e?.code === 4902) {
      await window.ethereum.request({
        method: "wallet_addEthereumChain",
        params: [{
          chainId: hexId,
          chainName: CONFIG.chainName,
          nativeCurrency: { name: "Sepolia ETH", symbol: "ETH", decimals: 18 },
          rpcUrls: [CONFIG.rpcUrl],
          blockExplorerUrls: [CONFIG.explorer],
        }],
      });
    } else {
      throw e;
    }
  }
}

async function connect() {
  hideBanner();
  if (!window.ethereum) {
    showBanner("No se detectó ninguna wallet. Instalá MetaMask (o similar) y recargá la página.", true);
    return;
  }
  try {
    await window.ethereum.request({ method: "eth_requestAccounts" });
    await ensureSepolia();
    await setup();
  } catch (e) {
    showBanner(friendlyError(e), true);
  }
}

async function setup() {
  // Se recrea el provider tras cambios de red/cuenta para evitar estados viejos
  state.provider = new ethers.BrowserProvider(window.ethereum);
  const net = await state.provider.getNetwork();
  const netPill = $("network");
  netPill.classList.remove("hidden");
  netPill.textContent = net.chainId === BigInt(CONFIG.chainId) ? CONFIG.chainName : `Red incorrecta (${net.chainId})`;
  netPill.classList.toggle("bad", net.chainId !== BigInt(CONFIG.chainId));

  state.signer = await state.provider.getSigner();
  state.address = await state.signer.getAddress();
  $("connectBtn").textContent = short(state.address);

  if (net.chainId !== BigInt(CONFIG.chainId)) {
    showBanner(`Cambiá tu wallet a ${CONFIG.chainName} para usar la app.`);
    state.xp = state.cred = null;
    await refresh();
    return;
  }
  if (!contractsConfigured()) {
    showBanner("Faltan las direcciones de los contratos en config.js (se completan tras el deploy en Sepolia).");
    state.xp = state.cred = null;
    await refresh();
    return;
  }

  state.xp = new ethers.Contract(CONFIG.mintXP, MINTXP_ABI, state.signer);
  state.cred = new ethers.Contract(CONFIG.mintCredential, CREDENTIAL_ABI, state.signer);
  [state.decimals, state.symbol] = await Promise.all([state.xp.decimals(), state.xp.symbol()]);
  state.decimals = Number(state.decimals);
  await refresh();
}

// ---------- lectura de estado ----------
async function refresh() {
  if (!state.address) return;
  $("walletEmpty").classList.add("hidden");
  $("walletInfo").classList.remove("hidden");
  $("addr").textContent = state.address;
  $("ethBal").textContent = Number(ethers.formatEther(await state.provider.getBalance(state.address))).toFixed(4);

  const acts = CONFIG.activities;
  if (!state.xp) {
    $("xpBal").textContent = "-";
    renderActivities(acts.map(() => false));
    renderCredential({ done: [], balance: 0n, cost: 0n, allowance: 0n, has: false });
    return;
  }

  try {
    const [balance, cost, allowance, has, ...done] = await Promise.all([
      state.xp.balanceOf(state.address),
      state.cred.burnCost(),
      state.xp.allowance(state.address, CONFIG.mintCredential),
      state.cred.hasCredential(state.address, CONFIG.pathId),
      ...acts.map((a) => state.xp.claimed(state.address, a.id)),
    ]);
    $("xpBal").textContent = `${fmt(balance)} ${state.symbol}`;
    renderActivities(done);
    renderCredential({ done, balance, cost, allowance, has });
  } catch (e) {
    showBanner("No se pudo leer el estado de los contratos: " + friendlyError(e), true);
  }
}

// ---------- render ----------
function renderActivities(done) {
  const ul = $("activities");
  ul.replaceChildren();
  CONFIG.activities.forEach((a, i) => {
    const li = document.createElement("li");
    const info = document.createElement("div");
    info.className = "info";
    const t = document.createElement("strong");
    t.textContent = a.title;
    const d = document.createElement("small");
    d.textContent = a.desc;
    info.append(t, d);

    const btn = document.createElement("button");
    if (done[i]) {
      btn.textContent = "Reclamado ✓";
      btn.disabled = true;
    } else {
      btn.textContent = "Hacer actividad";
      btn.disabled = !state.xp || state.busy;
      btn.addEventListener("click", () => openActivity(a));
    }
    li.append(info, btn);
    ul.append(li);
  });
}

function renderCredential({ done, balance, cost, allowance, has }) {
  const total = CONFIG.activities.length;
  const completed = done.filter(Boolean).length;
  const allDone = total > 0 && completed === total;
  const enough = balance >= cost && cost > 0n;
  const approved = allowance >= cost && cost > 0n;

  $("progress").textContent = `${completed}/${total}`;
  $("costInfo").textContent = state.xp ? `${fmt(balance)} de ${fmt(cost)} ${state.symbol} (se queman)` : "-";
  $("approveInfo").textContent = state.xp ? (approved ? "ya autorizado" : "se pedirá al reclamar") : "-";
  $("stepActivities").classList.toggle("done", allDone);
  $("stepBalance").classList.toggle("done", enough);
  $("stepApprove").classList.toggle("done", approved);

  $("credDone").classList.toggle("hidden", !has);
  const btn = $("credBtn");
  btn.disabled = !state.xp || state.busy || has || !allDone || !enough;
  btn.dataset.needsApprove = approved ? "0" : "1";
  btn.dataset.cost = cost.toString();

  $("transferBtn").disabled = !state.xp || state.busy;
}

// ---------- log de transacciones ----------
function addLog(label) {
  const ul = $("log");
  if (ul.firstElementChild?.classList.contains("muted")) ul.replaceChildren();
  const li = document.createElement("li");
  const text = document.createElement("span");
  text.textContent = label;
  const status = document.createElement("span");
  status.className = "tag-pending";
  status.textContent = "esperando firma…";
  li.append(text, status);
  ul.prepend(li);
  return { li, status };
}

function setLogTx(entry, hash) {
  const a = document.createElement("a");
  a.href = `${CONFIG.explorer}/tx/${hash}`;
  a.target = "_blank";
  a.rel = "noopener";
  a.textContent = `${hash.slice(0, 10)}… ↗`;
  entry.status.replaceChildren("confirmando… ", a);
}

function setLogDone(entry, ok, msg) {
  entry.status.className = ok ? "ok" : "tag-fail";
  const link = entry.status.querySelector("a");
  entry.status.replaceChildren(ok ? "confirmada " : `${msg} `);
  if (link && ok) entry.status.append(link);
}

// Envuelve una tx: la envía, muestra el hash y espera la confirmación
async function runTx(label, send) {
  const entry = addLog(label);
  state.busy = true;
  try {
    const tx = await send();
    setLogTx(entry, tx.hash);
    await tx.wait();
    setLogDone(entry, true);
    return true;
  } catch (e) {
    setLogDone(entry, false, friendlyError(e));
    return false;
  } finally {
    state.busy = false;
  }
}

// ---------- acciones ----------
async function claimActivity(activity) {
  hideBanner();
  let data;
  try {
    data = await postJson("/sign-claim", { user: state.address, activityId: activity.id });
  } catch (e) {
    showBanner("No se pudo obtener la autorización del backend: " + friendlyError(e), true);
    return;
  }
  await runTx(`Reclamar MXP: ${activity.title}`, () =>
    state.xp.claimXP(activity.id, BigInt(data.amount), BigInt(data.deadline), data.signature)
  );
  await refresh();
}

// ---------- backend: contenido y quiz ----------
async function api(path, options) {
  const res = await fetch(`${CONFIG.backendUrl}${path}`, options);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || `El backend respondió ${res.status}`);
  return body;
}

const postJson = (path, data) =>
  api(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

// Abre la lección y el quiz. Si el backend ya registra la actividad como aprobada, va directo al reclamo.
async function openActivity(activity) {
  hideBanner();
  try {
    const { passed } = await api(`/progress/${state.address}`);
    if (passed.includes(activity.id)) return claimActivity(activity);
    // con ?user el backend devuelve el juego de preguntas del intento actual, o solo la lección si está bloqueada
    const data = await api(`/activities/${activity.id}?user=${state.address}`);
    renderQuiz(activity, data);
    $("quizDialog").showModal();
  } catch (e) {
    showBanner("No se pudo cargar la actividad: " + friendlyError(e), true);
  }
}

// "23 h 59 min" a partir de segundos
function formatWait(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.ceil((seconds % 3600) / 60);
  return h > 0 ? `${h} h ${m} min` : `${m} min`;
}

function renderQuiz(activity, data) {
  $("quizTitle").textContent = data.title;
  const body = $("quizBody");
  body.replaceChildren();

  data.lesson.forEach((paragraph) => {
    const p = document.createElement("p");
    p.textContent = paragraph;
    body.append(p);
  });

  if (data.locked) {
    const notice = document.createElement("p");
    notice.className = "muted";
    notice.textContent = `Agotaste los ${data.maxAttempts ?? 3} intentos. Repasá la lección y volvé a intentarlo en ${formatWait(data.retryAfterSeconds)}.`;
    body.append(notice);
    return;
  }

  const attemptInfo = document.createElement("p");
  attemptInfo.className = "muted";
  attemptInfo.textContent = `Intento ${data.attempt} de ${data.maxAttempts}. Necesitás ${data.passScore} respuestas correctas de ${data.questions.length}.`;
  body.append(attemptInfo);

  const form = document.createElement("form");
  data.questions.forEach((q, qi) => {
    const fieldset = document.createElement("fieldset");
    const legend = document.createElement("legend");
    legend.textContent = `${qi + 1}. ${q.text}`;
    fieldset.append(legend);
    q.options.forEach((option, oi) => {
      const label = document.createElement("label");
      const input = document.createElement("input");
      input.type = "radio";
      input.name = `q${qi}`;
      input.value = String(oi);
      input.required = true;
      label.append(input, document.createTextNode(` ${option}`));
      fieldset.append(label);
    });
    form.append(fieldset);
  });

  const result = document.createElement("p");
  result.className = "muted";
  const submit = document.createElement("button");
  submit.type = "submit";
  submit.textContent = "Enviar respuestas";
  form.append(result, submit);

  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const fd = new FormData(form);
    const answers = data.questions.map((_, qi) => Number(fd.get(`q${qi}`)));
    submit.disabled = true;
    result.textContent = "Corrigiendo…";
    try {
      const r = await postJson("/submit-answers", { user: state.address, activityId: activity.id, answers });
      if (r.passed) {
        $("quizDialog").close();
        await claimActivity(activity);
      } else if (r.locked) {
        // tercer fallo: se muestra la lección para repasar y el tiempo de espera
        renderQuiz(activity, { ...data, questions: [], locked: true, retryAfterSeconds: r.retryAfterSeconds });
      } else {
        // sin puntaje: el siguiente intento trae preguntas distintas
        const data2 = await api(`/activities/${activity.id}?user=${state.address}`);
        renderQuiz(activity, data2);
        const msg = document.createElement("p");
        msg.className = "muted";
        msg.textContent = `No alcanzaste el mínimo. Releé la lección: quedan ${r.attemptsLeft} intento(s) y las preguntas cambian.`;
        $("quizBody").prepend(msg);
      }
    } catch (e) {
      result.textContent = friendlyError(e);
    } finally {
      submit.disabled = false;
    }
  });

  body.append(form);
}

async function claimCredential() {
  hideBanner();
  const btn = $("credBtn");
  const cost = BigInt(btn.dataset.cost);

  if (btn.dataset.needsApprove === "1") {
    // approve exacto: la credencial usa burnFrom, que necesita allowance del usuario
    const ok = await runTx(`Autorizar burn de ${fmt(cost)} ${state.symbol}`, () =>
      state.xp.approve(CONFIG.mintCredential, cost)
    );
    if (!ok) return refresh();
  }
  await runTx("Reclamar credencial (quema MXP)", () => state.cred.claimCredential(CONFIG.pathId));
  await refresh();
}

async function transfer(ev) {
  ev.preventDefault();
  hideBanner();
  const to = $("toInput").value.trim();
  if (!ethers.isAddress(to)) return showBanner("La dirección de destino no es válida.", true);
  let amount;
  try {
    amount = ethers.parseUnits($("amtInput").value, state.decimals);
  } catch {
    return showBanner("Cantidad inválida.", true);
  }
  if (amount <= 0n) return showBanner("La cantidad debe ser mayor a 0.", true);

  const ok = await runTx(`Transferir ${fmt(amount)} ${state.symbol} a ${short(to)}`, () =>
    state.xp.transfer(to, amount)
  );
  if (ok) $("transferForm").reset();
  await refresh();
}

// ---------- eventos de UI y wallet ----------
$("connectBtn").addEventListener("click", connect);
$("credBtn").addEventListener("click", claimCredential);
$("transferForm").addEventListener("submit", transfer);

if (window.ethereum) {
  window.ethereum.on?.("accountsChanged", (accs) => (accs.length ? setup() : location.reload()));
  window.ethereum.on?.("chainChanged", () => setup());
  // Reconexión silenciosa si el sitio ya tenía permiso
  window.ethereum.request({ method: "eth_accounts" }).then((accs) => accs.length && setup()).catch(() => {});
}

renderActivities(CONFIG.activities.map(() => false));
