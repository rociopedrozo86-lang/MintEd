// ABIs mínimas (formato humano de ethers v6).
// Deben coincidir con los contratos de Persona A; si cambia una firma, se ajusta acá.

export const MINTXP_ABI = [
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function balanceOf(address owner) view returns (uint256)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function transfer(address to, uint256 amount) returns (bool)",
  // Registro de claims: evita el doble claim por (usuario, actividad)
  "function claimed(address user, uint256 activityId) view returns (bool)",
  "function claimXP(uint256 activityId, uint256 amount, uint256 deadline, bytes signature)",
  "event XPClaimed(address indexed user, uint256 indexed activityId, uint256 amount)",
];

export const CREDENTIAL_ABI = [
  // Cantidad de MXP que se queman al reclamar (en unidades mínimas del token)
  "function burnCost() view returns (uint256)",
  "function hasCredential(address user, uint256 pathId) view returns (bool)",
  // Verifica on-chain las actividades completadas, quema MXP con burnFrom y mintea la credencial
  "function claimCredential(uint256 pathId)",
  "event CredentialClaimed(address indexed user, uint256 indexed pathId, uint256 tokenId)",
];
