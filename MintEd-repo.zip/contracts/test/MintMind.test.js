const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture, time } = require("@nomicfoundation/hardhat-toolbox/network-helpers");

const TEN = ethers.parseEther("10");
const COST = ethers.parseEther("20");
const BASE_URI = "ipfs://mintmind/";

async function deployFixture() {
  const [owner, signer, alice, bob, mallory] = await ethers.getSigners();

  const xp = await (await ethers.getContractFactory("MintXP")).deploy(signer.address);
  const cred = await (await ethers.getContractFactory("MintCredential")).deploy(
    await xp.getAddress(),
    COST,
    BASE_URI
  );
  await cred.createPath(1, [1, 2, 3]);

  const { chainId } = await ethers.provider.getNetwork();
  const domain = { name: "MintXP", version: "1", chainId, verifyingContract: await xp.getAddress() };
  const types = {
    Claim: [
      { name: "user", type: "address" },
      { name: "activityId", type: "uint256" },
      { name: "amount", type: "uint256" },
      { name: "deadline", type: "uint256" },
    ],
  };

  async function sign(by, user, activityId, amount = TEN, deadline) {
    if (deadline === undefined) deadline = (await time.latest()) + 3600;
    const signature = await by.signTypedData(domain, types, { user, activityId, amount, deadline });
    return { activityId, amount, deadline, signature };
  }

  async function claim(user, activityId, amount = TEN) {
    const c = await sign(signer, user.address, activityId, amount);
    return xp.connect(user).claimXP(c.activityId, c.amount, c.deadline, c.signature);
  }

  async function completePath(user) {
    for (const id of [1, 2, 3]) await claim(user, id);
  }

  return { owner, signer, alice, bob, mallory, xp, cred, sign, claim, completePath };
}

describe("MintXP", () => {
  it("se despliega con nombre, símbolo, owner y firmante", async () => {
    const { xp, owner, signer } = await loadFixture(deployFixture);
    expect(await xp.name()).to.equal("MintXP");
    expect(await xp.symbol()).to.equal("MXP");
    expect(await xp.owner()).to.equal(owner.address);
    expect(await xp.claimSigner()).to.equal(signer.address);
    expect(await xp.totalSupply()).to.equal(0n);
  });

  it("no permite firmante cero en el constructor", async () => {
    const f = await ethers.getContractFactory("MintXP");
    await expect(f.deploy(ethers.ZeroAddress)).to.be.revertedWithCustomError(f, "ZeroAddress");
  });

  describe("claimXP", () => {
    it("mintea MXP con firma válida, marca el claim y emite evento", async () => {
      const { xp, signer, alice, sign } = await loadFixture(deployFixture);
      const c = await sign(signer, alice.address, 1);
      await expect(xp.connect(alice).claimXP(c.activityId, c.amount, c.deadline, c.signature))
        .to.emit(xp, "XPClaimed")
        .withArgs(alice.address, 1, TEN);
      expect(await xp.balanceOf(alice.address)).to.equal(TEN);
      expect(await xp.claimed(alice.address, 1)).to.equal(true);
      expect(await xp.claimed(alice.address, 2)).to.equal(false);
    });

    it("impide el doble claim de la misma actividad", async () => {
      const { xp, alice, claim } = await loadFixture(deployFixture);
      await claim(alice, 1);
      await expect(claim(alice, 1)).to.be.revertedWithCustomError(xp, "AlreadyClaimed");
    });

    it("permite reclamar actividades distintas", async () => {
      const { xp, alice, claim } = await loadFixture(deployFixture);
      await claim(alice, 1);
      await claim(alice, 2);
      expect(await xp.balanceOf(alice.address)).to.equal(TEN * 2n);
    });

    it("rechaza firmas de quien no es el firmante autorizado", async () => {
      const { xp, mallory, alice, sign } = await loadFixture(deployFixture);
      const c = await sign(mallory, alice.address, 1);
      await expect(
        xp.connect(alice).claimXP(c.activityId, c.amount, c.deadline, c.signature)
      ).to.be.revertedWithCustomError(xp, "BadSignature");
    });

    it("rechaza una firma emitida para otro usuario", async () => {
      const { xp, signer, alice, bob, sign } = await loadFixture(deployFixture);
      const c = await sign(signer, bob.address, 1);
      await expect(
        xp.connect(alice).claimXP(c.activityId, c.amount, c.deadline, c.signature)
      ).to.be.revertedWithCustomError(xp, "BadSignature");
    });

    it("rechaza si se altera el monto firmado", async () => {
      const { xp, signer, alice, sign } = await loadFixture(deployFixture);
      const c = await sign(signer, alice.address, 1, TEN);
      await expect(
        xp.connect(alice).claimXP(c.activityId, ethers.parseEther("50"), c.deadline, c.signature)
      ).to.be.revertedWithCustomError(xp, "BadSignature");
    });

    it("rechaza reutilizar la firma en otra actividad", async () => {
      const { xp, signer, alice, sign } = await loadFixture(deployFixture);
      const c = await sign(signer, alice.address, 1);
      await expect(
        xp.connect(alice).claimXP(2, c.amount, c.deadline, c.signature)
      ).to.be.revertedWithCustomError(xp, "BadSignature");
    });

    it("rechaza firmas vencidas", async () => {
      const { xp, signer, alice, sign } = await loadFixture(deployFixture);
      const past = (await time.latest()) - 1;
      const c = await sign(signer, alice.address, 1, TEN, past);
      await expect(
        xp.connect(alice).claimXP(c.activityId, c.amount, c.deadline, c.signature)
      ).to.be.revertedWithCustomError(xp, "ClaimExpired");
    });

    it("rechaza montos en cero o por encima del tope", async () => {
      const { xp, signer, alice, sign } = await loadFixture(deployFixture);
      const max = await xp.MAX_CLAIM();

      const zero = await sign(signer, alice.address, 1, 0n);
      await expect(
        xp.connect(alice).claimXP(zero.activityId, zero.amount, zero.deadline, zero.signature)
      ).to.be.revertedWithCustomError(xp, "InvalidAmount");

      const big = await sign(signer, alice.address, 1, max + 1n);
      await expect(
        xp.connect(alice).claimXP(big.activityId, big.amount, big.deadline, big.signature)
      ).to.be.revertedWithCustomError(xp, "InvalidAmount");

      const ok = await sign(signer, alice.address, 1, max);
      await expect(xp.connect(alice).claimXP(ok.activityId, ok.amount, ok.deadline, ok.signature)).to.not.be.reverted;
    });
  });

  describe("administración del firmante", () => {
    it("el owner puede rotar el firmante y las firmas del anterior dejan de valer", async () => {
      const { xp, signer, mallory, alice, sign } = await loadFixture(deployFixture);
      const old = await sign(signer, alice.address, 1);

      await expect(xp.setClaimSigner(mallory.address))
        .to.emit(xp, "ClaimSignerUpdated")
        .withArgs(signer.address, mallory.address);

      await expect(
        xp.connect(alice).claimXP(old.activityId, old.amount, old.deadline, old.signature)
      ).to.be.revertedWithCustomError(xp, "BadSignature");

      const fresh = await sign(mallory, alice.address, 1);
      await expect(xp.connect(alice).claimXP(fresh.activityId, fresh.amount, fresh.deadline, fresh.signature)).to.not.be
        .reverted;
    });

    it("solo el owner puede rotar el firmante y no acepta cero", async () => {
      const { xp, alice } = await loadFixture(deployFixture);
      await expect(xp.connect(alice).setClaimSigner(alice.address)).to.be.revertedWithCustomError(
        xp,
        "OwnableUnauthorizedAccount"
      );
      await expect(xp.setClaimSigner(ethers.ZeroAddress)).to.be.revertedWithCustomError(xp, "ZeroAddress");
    });
  });

  describe("ERC-20", () => {
    it("permite transferir y quemar", async () => {
      const { xp, alice, bob, claim } = await loadFixture(deployFixture);
      await claim(alice, 1);
      await xp.connect(alice).transfer(bob.address, ethers.parseEther("4"));
      expect(await xp.balanceOf(bob.address)).to.equal(ethers.parseEther("4"));

      await xp.connect(alice).burn(ethers.parseEther("6"));
      expect(await xp.balanceOf(alice.address)).to.equal(0n);
      expect(await xp.totalSupply()).to.equal(ethers.parseEther("4"));
    });
  });
});

describe("MintCredential", () => {
  describe("despliegue y paths", () => {
    it("guarda xp, costo de burn y path inicial", async () => {
      const { cred, xp } = await loadFixture(deployFixture);
      expect(await cred.xp()).to.equal(await xp.getAddress());
      expect(await cred.burnCost()).to.equal(COST);
      expect(await cred.pathExists(1)).to.equal(true);
      expect((await cred.getPathActivities(1)).map(Number)).to.deep.equal([1, 2, 3]);
    });

    it("valida los argumentos del constructor", async () => {
      const { xp } = await loadFixture(deployFixture);
      const f = await ethers.getContractFactory("MintCredential");
      await expect(f.deploy(ethers.ZeroAddress, COST, "")).to.be.revertedWithCustomError(f, "ZeroAddress");
      await expect(f.deploy(await xp.getAddress(), 0, "")).to.be.revertedWithCustomError(f, "InvalidBurnCost");
    });

    it("solo el owner crea paths; no se pueden duplicar ni dejar vacíos", async () => {
      const { cred, alice } = await loadFixture(deployFixture);
      await expect(cred.connect(alice).createPath(2, [1])).to.be.revertedWithCustomError(
        cred,
        "OwnableUnauthorizedAccount"
      );
      await expect(cred.createPath(1, [9])).to.be.revertedWithCustomError(cred, "PathAlreadyExists").withArgs(1);
      await expect(cred.createPath(2, [])).to.be.revertedWithCustomError(cred, "InvalidPath");
      await expect(cred.createPath(2, Array.from({ length: 33 }, (_, i) => i + 1))).to.be.revertedWithCustomError(
        cred,
        "InvalidPath"
      );
      await expect(cred.createPath(2, [7, 8])).to.emit(cred, "PathCreated").withArgs(2, [7, 8]);
    });
  });

  describe("claimCredential", () => {
    it("revierte si el path no existe", async () => {
      const { cred, alice } = await loadFixture(deployFixture);
      await expect(cred.connect(alice).claimCredential(99))
        .to.be.revertedWithCustomError(cred, "UnknownPath")
        .withArgs(99);
    });

    it("revierte si faltan actividades e indica cuál", async () => {
      const { cred, alice, claim } = await loadFixture(deployFixture);
      await claim(alice, 1);
      await claim(alice, 2);
      await expect(cred.connect(alice).claimCredential(1))
        .to.be.revertedWithCustomError(cred, "PathIncomplete")
        .withArgs(3);
    });

    it("revierte sin allowance", async () => {
      const { cred, xp, alice, completePath } = await loadFixture(deployFixture);
      await completePath(alice);
      await expect(cred.connect(alice).claimCredential(1)).to.be.revertedWithCustomError(
        xp,
        "ERC20InsufficientAllowance"
      );
    });

    it("revierte sin saldo suficiente aunque haya allowance", async () => {
      const { cred, xp, alice, bob, completePath } = await loadFixture(deployFixture);
      await completePath(alice); // 30 MXP
      await xp.connect(alice).transfer(bob.address, ethers.parseEther("15")); // quedan 15 < 20
      await xp.connect(alice).approve(await cred.getAddress(), COST);
      await expect(cred.connect(alice).claimCredential(1)).to.be.revertedWithCustomError(
        xp,
        "ERC20InsufficientBalance"
      );
    });

    it("quema MXP, mintea la credencial y emite eventos", async () => {
      const { cred, xp, alice, completePath } = await loadFixture(deployFixture);
      await completePath(alice);
      await xp.connect(alice).approve(await cred.getAddress(), COST);
      const supplyBefore = await xp.totalSupply();

      await expect(cred.connect(alice).claimCredential(1))
        .to.emit(cred, "CredentialClaimed")
        .withArgs(alice.address, 1, 1)
        .and.to.emit(cred, "Locked")
        .withArgs(1);

      expect(await xp.balanceOf(alice.address)).to.equal(TEN); // 30 - 20
      expect(await xp.totalSupply()).to.equal(supplyBefore - COST); // se quemó de verdad
      expect(await cred.ownerOf(1)).to.equal(alice.address);
      expect(await cred.balanceOf(alice.address)).to.equal(1n);
      expect(await cred.hasCredential(alice.address, 1)).to.equal(true);
      expect(await cred.tokenPath(1)).to.equal(1n);
      expect(await cred.locked(1)).to.equal(true);
      expect(await cred.tokenURI(1)).to.equal(BASE_URI + "1");
      expect(await xp.allowance(alice.address, await cred.getAddress())).to.equal(0n);
    });

    it("no permite reclamar dos veces el mismo path", async () => {
      const { cred, xp, alice, completePath } = await loadFixture(deployFixture);
      await completePath(alice);
      await xp.connect(alice).approve(await cred.getAddress(), COST * 2n);
      await cred.connect(alice).claimCredential(1);
      await expect(cred.connect(alice).claimCredential(1)).to.be.revertedWithCustomError(
        cred,
        "AlreadyHasCredential"
      );
    });

    it("la credencial de un usuario no depende del progreso de otro", async () => {
      const { cred, xp, alice, bob, completePath } = await loadFixture(deployFixture);
      await completePath(alice);
      await xp.connect(alice).transfer(bob.address, ethers.parseEther("30")); // bob tiene MXP pero no actividades
      await xp.connect(bob).approve(await cred.getAddress(), COST);
      await expect(cred.connect(bob).claimCredential(1))
        .to.be.revertedWithCustomError(cred, "PathIncomplete")
        .withArgs(1);
    });
  });

  describe("soulbound (ERC-5192)", () => {
    async function withCredential() {
      const base = await deployFixture();
      await base.completePath(base.alice);
      await base.xp.connect(base.alice).approve(await base.cred.getAddress(), COST);
      await base.cred.connect(base.alice).claimCredential(1);
      return base;
    }

    it("bloquea transferencias", async () => {
      const { cred, alice, bob } = await loadFixture(withCredential);
      await expect(
        cred.connect(alice).transferFrom(alice.address, bob.address, 1)
      ).to.be.revertedWithCustomError(cred, "Soulbound");
      await expect(
        cred.connect(alice)["safeTransferFrom(address,address,uint256)"](alice.address, bob.address, 1)
      ).to.be.revertedWithCustomError(cred, "Soulbound");
    });

    it("tampoco permite que un operador aprobado la mueva", async () => {
      const { cred, alice, bob } = await loadFixture(withCredential);
      await cred.connect(alice).approve(bob.address, 1);
      await expect(
        cred.connect(bob).transferFrom(alice.address, bob.address, 1)
      ).to.be.revertedWithCustomError(cred, "Soulbound");
    });

    it("anuncia las interfaces ERC-5192, ERC-721 y ERC-165", async () => {
      const { cred } = await loadFixture(deployFixture);
      expect(await cred.supportsInterface("0xb45a3c0e")).to.equal(true);
      expect(await cred.supportsInterface("0x80ac58cd")).to.equal(true);
      expect(await cred.supportsInterface("0x01ffc9a7")).to.equal(true);
      expect(await cred.supportsInterface("0xffffffff")).to.equal(false);
    });

    it("locked() revierte para tokens inexistentes", async () => {
      const { cred } = await loadFixture(deployFixture);
      await expect(cred.locked(42)).to.be.revertedWithCustomError(cred, "ERC721NonexistentToken");
    });
  });
});
