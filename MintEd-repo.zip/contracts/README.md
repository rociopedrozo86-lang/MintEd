# Mint Mind — Contratos

Contratos del MVP de Mint Mind (Sepolia):

- **`MintXP` (MXP)**: ERC-20 + `ERC20Burnable`. Se emite solo con una firma EIP-712 del `claimSigner`.
- **`MintCredential`**: ERC-721 no transferible (soulbound, compatible con ERC-5192). Exige haber completado las actividades del path y quema MXP al reclamarse.

## Requisitos

Node 18+ y una wallet de testnet con ETH de Sepolia (faucet).

```bash
npm install
cp .env.example .env   # completar valores
npm test
```

## Flujo on-chain

```
backend firma Claim(user, activityId, amount, deadline)   (EIP-712, off-chain)
        ↓
usuario → MintXP.claimXP(...)       verifica firma, deadline, tope y que no se haya reclamado
        ↓                           claimed[user][activityId] = true  →  mint de MXP
usuario → MintXP.approve(MintCredential, burnCost)
        ↓
usuario → MintCredential.claimCredential(pathId)
                                    verifica claimed[...] de cada actividad del path
                                    MintXP.burnFrom(user, burnCost)  →  mint del NFT (bloqueado)
```

## Despliegue en Sepolia

1. En `.env`: `SEPOLIA_RPC_URL`, `PRIVATE_KEY` (wallet solo de testnet), `ETHERSCAN_API_KEY` y `CLAIM_SIGNER_ADDRESS` (la dirección de la wallet que usará el backend para firmar; la clave privada del firmante NO va acá).
2. `npm run deploy:sepolia`
3. El script despliega ambos contratos, crea el path 1 con las actividades `[1, 2, 3]`, guarda las direcciones en `deployments/sepolia.json`, intenta verificar el código en Etherscan e imprime las líneas para pegar en `front/config.js`.

Parámetros por defecto: 20 MXP de costo de credencial (`BURN_COST`). El backend debería firmar 10 MXP por actividad, así que completar el path da 30 MXP y la credencial deja 10.

## Decisiones de diseño

| Decisión | Motivo |
|---|---|
| Claim con firma EIP-712 del backend | El contrato no puede saber si se completó una actividad off-chain; el firmante es el único punto de confianza y queda explícito |
| `claimed[user][activityId]` en vez de nonces | Cada par se reclama una sola vez, así que cumple de registro de progreso y de protección contra replay |
| Firma atada a `user`, `activityId`, `amount` y `deadline` | No se puede reutilizar en otra cuenta, otra actividad ni con otro monto |
| `MAX_CLAIM` (100 MXP) y `setClaimSigner` | Limitan el daño y permiten rotar la clave si el firmante se compromete |
| El progreso se verifica on-chain en la credencial | La credencial no depende de que el backend vuelva a decir nada |
| `burnCost` inmutable y paths no editables | El owner no puede encarecer ni cambiar los requisitos después de desplegar |
| `_mint` y no `_safeMint` en la credencial | Evita el callback `onERC721Received` y un vector de reentrancia |
| Soulbound bloqueando `_update` | Impide transferencias y burns; `locked()` y el evento `Locked` siguen ERC-5192 |

## Riesgos y límites conocidos (para el whitepaper)

- **Firmante centralizado**: si el backend firma de más, se emiten MXP indebidos. Mitigación parcial: tope por claim, rotación del firmante, un claim por actividad.
- **Sybil / multi-wallet**: nada impide que una persona use varias wallets. No se resuelve en el MVP.
- **Bots**: la validación de que una actividad se hizo de verdad depende del backend.
- **Compra de MXP**: el token es transferible, pero la credencial exige haber completado las actividades con esa misma wallet, así que comprar MXP no alcanza.
- **Owner único**: el owner puede rotar el firmante; en producción debería ser un multisig.
