const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

async function main() {
  const { ethers, network, run } = hre;
  const [deployer] = await ethers.getSigners();
  if (!deployer) throw new Error("No hay cuenta para desplegar: completá PRIVATE_KEY en .env");

  const claimSigner = process.env.CLAIM_SIGNER_ADDRESS;
  if (!claimSigner || !ethers.isAddress(claimSigner)) {
    throw new Error("Completá CLAIM_SIGNER_ADDRESS (dirección válida) en .env");
  }
  const burnCost = ethers.parseEther(process.env.BURN_COST || "20");
  const baseURI = process.env.CREDENTIAL_BASE_URI || "";

  console.log(`Red: ${network.name}`);
  console.log(`Deployer: ${deployer.address}`);
  console.log(`Balance: ${ethers.formatEther(await ethers.provider.getBalance(deployer.address))} ETH`);
  console.log(`Firmante de claims: ${claimSigner}`);
  console.log(`Costo de la credencial: ${ethers.formatEther(burnCost)} MXP\n`);

  // 1) MintXP
  const xp = await (await ethers.getContractFactory("MintXP")).deploy(claimSigner);
  await xp.waitForDeployment();
  const xpAddress = await xp.getAddress();
  console.log(`MintXP desplegado en ${xpAddress}`);

  // 2) MintCredential
  const cred = await (await ethers.getContractFactory("MintCredential")).deploy(xpAddress, burnCost, baseURI);
  await cred.waitForDeployment();
  const credAddress = await cred.getAddress();
  console.log(`MintCredential desplegado en ${credAddress}`);

  // 3) Learning path 1 = actividades 1, 2 y 3 (coincide con config.js del front)
  const tx = await cred.createPath(1, [1, 2, 3]);
  await tx.wait();
  console.log("Path 1 creado con actividades [1, 2, 3]");

  // 4) Guardar direcciones
  const out = {
    network: network.name,
    chainId: Number((await ethers.provider.getNetwork()).chainId),
    deployer: deployer.address,
    claimSigner,
    burnCost: burnCost.toString(),
    mintXP: xpAddress,
    mintCredential: credAddress,
    deployedAt: new Date().toISOString(),
  };
  const dir = path.join(__dirname, "..", "deployments");
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${network.name}.json`);
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
  console.log(`\nDirecciones guardadas en ${path.relative(process.cwd(), file)}`);

  // 5) Verificar en Etherscan (solo redes públicas)
  if (network.name !== "hardhat" && network.name !== "localhost" && process.env.ETHERSCAN_API_KEY) {
    console.log("\nEsperando confirmaciones para verificar...");
    await cred.deploymentTransaction().wait(5);
    const verify = async (address, constructorArguments) => {
      try {
        await run("verify:verify", { address, constructorArguments });
      } catch (e) {
        console.log(`Verificación de ${address}: ${e.message.split("\n")[0]}`);
      }
    };
    await verify(xpAddress, [claimSigner]);
    await verify(credAddress, [xpAddress, burnCost, baseURI]);
  }

  console.log("\nPegar en front/config.js:");
  console.log(`  mintXP: "${xpAddress}",`);
  console.log(`  mintCredential: "${credAddress}",`);
}

main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
