// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

interface IMintXP {
    function claimed(address user, uint256 activityId) external view returns (bool);
    function burnFrom(address account, uint256 value) external;
}

/// @title MintCredential
/// @notice Credencial educativa no transferible (soulbound, compatible con ERC-5192).
/// @dev Para reclamarla hay que (1) haber completado on-chain todas las actividades del path
///      (registro `claimed` de MintXP) y (2) pagar `burnCost` MXP, que se queman con burnFrom
///      (el usuario debe haber hecho `approve` antes). Un solo reclamo por (usuario, path).
contract MintCredential is ERC721, Ownable {
    IMintXP public immutable xp;
    /// @notice MXP que se queman al reclamar. Inmutable: el owner no puede encarecerla.
    uint256 public immutable burnCost;

    uint256 public constant MAX_ACTIVITIES_PER_PATH = 32;

    uint256 private _nextTokenId = 1;
    string private _baseTokenURI;

    mapping(uint256 => bool) public pathExists;
    mapping(uint256 => uint256[]) private _pathActivities;
    mapping(address => mapping(uint256 => bool)) public hasCredential;
    mapping(uint256 => uint256) public tokenPath;

    event PathCreated(uint256 indexed pathId, uint256[] activityIds);
    event CredentialClaimed(address indexed user, uint256 indexed pathId, uint256 tokenId);
    /// @dev ERC-5192
    event Locked(uint256 tokenId);
    event Unlocked(uint256 tokenId);

    error ZeroAddress();
    error InvalidBurnCost();
    error UnknownPath(uint256 pathId);
    error PathAlreadyExists(uint256 pathId);
    error InvalidPath();
    error PathIncomplete(uint256 missingActivityId);
    error AlreadyHasCredential();
    error Soulbound();

    constructor(address xp_, uint256 burnCost_, string memory baseURI_) ERC721("MintMind Credential", "MMC") Ownable(msg.sender) {
        if (xp_ == address(0)) revert ZeroAddress();
        if (burnCost_ == 0) revert InvalidBurnCost();
        xp = IMintXP(xp_);
        burnCost = burnCost_;
        _baseTokenURI = baseURI_;
    }

    /// @notice Define un learning path (lista de actividades requeridas).
    /// @dev Un path no se puede modificar una vez creado: los requisitos no cambian a mitad de camino.
    function createPath(uint256 pathId, uint256[] calldata activityIds) external onlyOwner {
        if (pathExists[pathId]) revert PathAlreadyExists(pathId);
        if (activityIds.length == 0 || activityIds.length > MAX_ACTIVITIES_PER_PATH) revert InvalidPath();
        pathExists[pathId] = true;
        _pathActivities[pathId] = activityIds;
        emit PathCreated(pathId, activityIds);
    }

    function getPathActivities(uint256 pathId) external view returns (uint256[] memory) {
        return _pathActivities[pathId];
    }

    /// @notice Reclama la credencial del path: verifica actividades, quema MXP y mintea el NFT.
    function claimCredential(uint256 pathId) external {
        if (!pathExists[pathId]) revert UnknownPath(pathId);
        if (hasCredential[msg.sender][pathId]) revert AlreadyHasCredential();

        uint256[] storage ids = _pathActivities[pathId];
        uint256 len = ids.length;
        for (uint256 i = 0; i < len; i++) {
            if (!xp.claimed(msg.sender, ids[i])) revert PathIncomplete(ids[i]);
        }

        // Efectos antes de las interacciones externas.
        hasCredential[msg.sender][pathId] = true;
        uint256 tokenId = _nextTokenId++;
        tokenPath[tokenId] = pathId;

        // Revierte si falta balance o allowance.
        xp.burnFrom(msg.sender, burnCost);

        // _mint (no _safeMint) a propósito: evita el callback onERC721Received y un vector de reentrancia.
        _mint(msg.sender, tokenId);

        emit CredentialClaimed(msg.sender, pathId, tokenId);
        emit Locked(tokenId);
    }

    /// @notice ERC-5192: toda credencial está bloqueada para siempre.
    function locked(uint256 tokenId) external view returns (bool) {
        _requireOwned(tokenId);
        return true;
    }

    function setBaseURI(string calldata newBaseURI) external onlyOwner {
        _baseTokenURI = newBaseURI;
    }

    function supportsInterface(bytes4 interfaceId) public view override returns (bool) {
        return interfaceId == 0xb45a3c0e /* ERC-5192 */ || super.supportsInterface(interfaceId);
    }

    function _baseURI() internal view override returns (string memory) {
        return _baseTokenURI;
    }

    /// @dev Solo se permite el mint (from == 0). Bloquea transferencias y burns.
    function _update(address to, uint256 tokenId, address auth) internal override returns (address) {
        if (_ownerOf(tokenId) != address(0)) revert Soulbound();
        return super._update(to, tokenId, auth);
    }
}
