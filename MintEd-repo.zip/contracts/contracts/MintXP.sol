// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Burnable} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

/// @title MintXP (MXP)
/// @notice Token ERC-20 que se gana al completar actividades educativas.
/// @dev La emisión NO es libre: cada claim exige una firma EIP-712 del `claimSigner`
///      (un backend que valida off-chain que la actividad se completó). Eso hace que el
///      firmante sea un punto de confianza centralizado, mitigado con: tope por claim,
///      deadline en cada firma, un solo claim por (usuario, actividad) y rotación del firmante.
contract MintXP is ERC20, ERC20Burnable, EIP712, Ownable {
    bytes32 private constant CLAIM_TYPEHASH =
        keccak256("Claim(address user,uint256 activityId,uint256 amount,uint256 deadline)");

    /// @notice Tope de MXP por claim: limita el daño si se compromete la clave del firmante.
    uint256 public constant MAX_CLAIM = 100 ether;

    /// @notice Dirección autorizada a firmar claims.
    address public claimSigner;

    /// @notice claimed[usuario][actividad]: protege contra el doble claim y hace de registro de progreso.
    mapping(address => mapping(uint256 => bool)) public claimed;

    event XPClaimed(address indexed user, uint256 indexed activityId, uint256 amount);
    event ClaimSignerUpdated(address indexed oldSigner, address indexed newSigner);

    error ZeroAddress();
    error ClaimExpired();
    error InvalidAmount();
    error AlreadyClaimed();
    error BadSignature();

    constructor(address signer) ERC20("MintXP", "MXP") EIP712("MintXP", "1") Ownable(msg.sender) {
        if (signer == address(0)) revert ZeroAddress();
        claimSigner = signer;
        emit ClaimSignerUpdated(address(0), signer);
    }

    /// @notice Reclama MXP por una actividad con una firma emitida por `claimSigner`.
    /// @param activityId Identificador de la actividad.
    /// @param amount Cantidad de MXP (en unidades mínimas, 18 decimales).
    /// @param deadline Timestamp límite de validez de la firma.
    /// @param signature Firma EIP-712 de Claim(msg.sender, activityId, amount, deadline).
    function claimXP(uint256 activityId, uint256 amount, uint256 deadline, bytes calldata signature) external {
        if (block.timestamp > deadline) revert ClaimExpired();
        if (amount == 0 || amount > MAX_CLAIM) revert InvalidAmount();
        if (claimed[msg.sender][activityId]) revert AlreadyClaimed();

        bytes32 structHash = keccak256(abi.encode(CLAIM_TYPEHASH, msg.sender, activityId, amount, deadline));
        address recovered = ECDSA.recover(_hashTypedDataV4(structHash), signature);
        if (recovered != claimSigner) revert BadSignature();

        // Checks-effects-interactions: se marca antes de mintear.
        claimed[msg.sender][activityId] = true;
        _mint(msg.sender, amount);

        emit XPClaimed(msg.sender, activityId, amount);
    }

    /// @notice Permite rotar el firmante (por ejemplo, ante una clave comprometida).
    function setClaimSigner(address newSigner) external onlyOwner {
        if (newSigner == address(0)) revert ZeroAddress();
        emit ClaimSignerUpdated(claimSigner, newSigner);
        claimSigner = newSigner;
    }
}
